"""Пример плагина-действия: дописать заметку в Документы/Заметки Джарвиса.txt."""

import datetime
import os


def append(params, context):
    text = str(params.get("text") or "").strip()
    if not text:
        raise ValueError("пустая заметка")
    folder = context.get("settings", {}).get("folder") or os.path.join(os.path.expanduser("~"), "Documents")
    path = os.path.join(folder, "Заметки Джарвиса.txt")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now():%d.%m.%Y %H:%M}  {text}\n")
    return {"say": "Записал заметку.", "file": path}


run = append

"""Пример плагина с сетью: открывается ли сайт и за сколько."""

import time
import urllib.error
import urllib.request


def check(params, context):
    url = str(params.get("url") or "").strip()
    if not url.startswith(("http://", "https://")):
        raise ValueError("адрес должен начинаться с http:// или https://")
    started = time.monotonic()
    try:
        with urllib.request.urlopen(urllib.request.Request(url, method="HEAD"), timeout=8) as response:
            code = response.status
    except urllib.error.HTTPError as error:
        code = error.code
    ms = round((time.monotonic() - started) * 1000)
    ok = code < 400
    return {"ok": ok, "code": code, "ms": ms,
            "say": f"Сайт отвечает за {ms} миллисекунд." if ok else f"Сайт ответил ошибкой {code}."}


run = check

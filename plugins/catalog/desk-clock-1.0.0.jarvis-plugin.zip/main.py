"""Example extension; all calculations are local and need no extra dependencies."""
import datetime


def widget(params, context):
    now = datetime.datetime.now()
    return {"title": "Сейчас", "text": now.strftime("%H:%M"), "rows": [
        {"label": "Дата", "value": now.strftime("%d.%m.%Y")},
        {"label": "Обработка", "value": "На этом компьютере"}]}


def trigger(params, context):
    return {"active": params.get("event") == "minute", "key": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}
